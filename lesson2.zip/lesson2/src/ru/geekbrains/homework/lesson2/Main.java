package ru.geekbrains.homework.lesson2;

public class Main {

    public static void main(String[] args) {
        System.out.println("1. Задать целочисленный массив, состоящий из элементов 0 и 1. Например: [ 1, 1, 0, 0, 1, 0, 1, 1, 0, 0 ]. С помощью цикла и условия заменить 0 на 1, 1 на 0;");
	int [] binaryChange = {1, 1, 0, 0, 1, 0, 1, 1, 0, 0};


            for(int x =0; x < binaryChange.length; x++ ){

                if(binaryChange[x]>0){
                    binaryChange[x]=binaryChange[x]-1;
                }
                else{
                    binaryChange[x]=binaryChange[x]+1;

                }
                System.out.println(binaryChange [x]);

            }
        System.out.println("2. Задать пустой целочисленный массив размером 8. С помощью цикла заполнить его значениями 0 3 6 9 12 15 18 21;");

        int [] eightNumbers = new int[8];

        for(int x=0;x<eightNumbers.length;x++){
            eightNumbers[x]=x*3;
            System.out.println(eightNumbers[x]);
        }

        System.out.println("3. Задать массив [ 1, 5, 3, 2, 11, 4, 5, 2, 4, 8, 9, 1 ] пройти по нему циклом, и числа меньшие 6 умножить на 2;");

        int[] multiplyIfLowThenSix = {1,5,3,2,11,4,5,2,4,8,9,1};
        for (int x =0; x < multiplyIfLowThenSix.length; x++){
            if(multiplyIfLowThenSix[x]<6){
                multiplyIfLowThenSix[x]=multiplyIfLowThenSix[x]*2;
            }
            else{}
            System.out.println(multiplyIfLowThenSix[x]);
        }

        System.out.println("4. Создать квадратный двумерный целочисленный массив (количество строк и столбцов одинаковое), и с помощью цикла(-ов) заполнить его диагональные элементы единицами;");

         int counter = 1;
        int[][] table = new int[4][4];
        for (int i = 0; i < 4; i++) {

            for (int j = 0; j < 4; j++) {

                table[0][0]=table[1][1]=table[2][2]=table[3][3]=counter;


                    System.out.print(table[i][j]);


            }
            System.out.println(" ");

        }

        System.out.println("5. ** Задать одномерный массив и найти в нем минимальный и максимальный элементы (без помощи интернета);");
        int[] star = {4,0,0,23,23,8};

        boolean hi1 = star[0]>=star[1] && star[0]>=star[2] && star[0]>=star[3] && star[0]>=star[4] && star[0]>=star[5];
        boolean hi2 = star[1]>=star[0] && star[1]>=star[2] && star[1]>=star[3] && star[1]>=star[4] && star[1]>=star[5];
        boolean hi3 = star[2]>=star[1] && star[2]>=star[0] && star[2]>=star[3] && star[2]>=star[4] && star[2]>=star[5];
        boolean hi4 = star[3]>=star[1] && star[3]>=star[2] && star[3]>=star[0] && star[3]>=star[4] && star[3]>=star[5];
        boolean hi5 = star[4]>=star[1] && star[4]>=star[2] && star[4]>=star[3] && star[4]>=star[0] && star[4]>=star[5];
        boolean hi6 = star[5]>=star[1] && star[5]>=star[2] && star[5]>=star[3] && star[5]>=star[4] && star[5]>=star[0];

        if(hi1==true){
            System.out.println(star[0] + " Наибольшее число в массиве");
        }
        else  if(hi2==true){
            System.out.println(star[1] + " Наибольшее число в массиве");
        }
        else  if(hi3==true){
            System.out.println(star[2] + " Наибольшее число в массиве");
        }
        else  if(hi4==true){
            System.out.println(star[3] + " Наибольшее число в массиве");
        }
        else  if(hi5==true){
            System.out.println(star[4] + " Наибольшее число в массиве");
        }
        else {
            System.out.println(star[5] + " Наибольшее число в массиве");
        }

        boolean low1 = star[0]<=star[1] && star[0]<=star[2] && star[0]<=star[3] && star[0]<=star[4] && star[0]<=star[5];
        boolean low2 = star[1]<=star[0] && star[1]<=star[2] && star[1]<=star[3] && star[1]<=star[4] && star[1]<=star[5];
        boolean low3 = star[2]<=star[1] && star[2]<=star[0] && star[2]<=star[3] && star[2]<=star[4] && star[2]<=star[5];
        boolean low4 = star[3]<=star[1] && star[3]<=star[2] && star[3]<=star[0] && star[3]<=star[4] && star[3]<=star[5];
        boolean low5 = star[4]<=star[1] && star[4]<=star[2] && star[4]<=star[3] && star[4]<=star[0] && star[4]<=star[5];
        boolean low6 = star[5]<=star[1] && star[5]<=star[2] && star[5]<=star[3] && star[5]<=star[4] && star[5]<=star[0];

        if(low1==true){
            System.out.println(star[0] + " Наименьшее число в массиве");
        }
        else  if(low2==true){
            System.out.println(star[1] + " Наименьшее число в массиве");
        }
        else  if(low3==true){
            System.out.println(star[2] + " Наименьшее число в массиве");
        }
        else  if(low4==true){
            System.out.println(star[3] + " Наименьшее число в массиве");
        }
        else  if(low5==true){
            System.out.println(star[4] + " Наименьшее число в массиве");
        }
        else {
            System.out.println(star[5] + " Наименьшее число в массиве");
        }

        System.out.println("6. ** Написать метод, в который передается не пустой одномерный целочисленный массив, метод должен вернуть true, если в массиве есть место, в котором сумма левой и правой части массива равны.");

        System.out.println( "Есть ли баланс в массиве " + getBalance(new int[]{7,2,3,5,2,}));
    }

    public static boolean getBalance(int[] checkBalance){



        boolean balance1 = checkBalance[0] == checkBalance[1] + checkBalance[2] + checkBalance[3] + checkBalance[4];
        boolean balance2 = checkBalance[0] + checkBalance[1] == checkBalance[2] + checkBalance[3] + checkBalance[4];
        boolean balance3 = checkBalance[0] + checkBalance[1] + checkBalance[2] == checkBalance[3] + checkBalance[4];
        boolean balance4 = checkBalance[0] + checkBalance[1] + checkBalance[2] + checkBalance[3] == checkBalance[4];
        boolean resultReturn = balance1 == true || balance2 == true || balance3 == true || balance4 == true;
        return resultReturn;



   }




















}
